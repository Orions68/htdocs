<?php
include "inc/fw.php";
$title = "Agregando un Cliente para Delivery";
include "inc/header.php";
$name = htmlspecialchars($_POST['name']);
$pass = htmlspecialchars($_POST['pass']);
$hash = password_hash($pass, PASSWORD_DEFAULT);
$email = htmlspecialchars($_POST['email']);
$phone = htmlspecialchars($_POST['phone']);
$address = htmlspecialchars($_POST['address']);
$stmt = $conn->prepare('INSERT INTO delivery VALUES(:id, :name, :email, :pass, :phone, :address)');
$stmt->execute(array(':id' => null, ':name' => $name, ':email' => $email, ':pass' => $hash, ':phone' => $phone, ':address' => $address));
echo "<script>if (!alert('Cliente : " . $name . " Agregado Correctamente.')) window.close('_self')</script>";
$title = "Agregando un Cliente";
include "inc/header.php";
?>
<section class="container-fluid pt-3">
<div id="pc"></div>
    <div id="mobile"></div>
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                </div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<?php
include "inc/footer.html";
?>