<?php
$title = "Formulario para Agregar un Cliente";
include "inc/header.php";
?>
<section class="container-fluid pt-3">
<div id="pc"></div>
    <div id="mobile"></div>
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                    <br><br><br><br>
                    <form action="addingUser.php" method="post">
                    <label><input type="text" name="name"> Nombre</label>
                    <br><br>
                    <label><input type="password" name="pass"> Contraseña</label>
                    <br><br>
                    <label><input type="password" name="pass2"> Repite Contraseña</label>
                    <br><br>
                    <label><input type="text" name="email"> E-mail</label>
                    <br><br>
                    <label><input type="text" name="phone"> Teléfono</label>
                    <br><br>
                    <label><input type="text" name="address"> Dirección</label>
                    <br><br>
                    <input type="button" value="Agrega" onclick="verify(this.form)">
                    </form>
                </div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<?php
include "inc/footer.html";
?>