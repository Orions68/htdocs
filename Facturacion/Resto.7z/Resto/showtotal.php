<?php
include "inc/fw.php";
$final = 0;
$title = "Total Facturado Hasta Ahora en el Año";
include "inc/header.php";

$stmt = $conn->prepare('SELECT totaliva FROM invoice');
$stmt->execute();
while($row = $stmt->fetch(PDO::FETCH_OBJ))
{
	$final += $row->totaliva;
}
?>
<section class="container-fluid pt-3">
    <div class="row">
        <div class="col-md-1"></div>
            <div class="col-md-10">
                <div id="view1">
                    <br><br>
					<h1>La Facturación de todo el año hasta ahora es: <?php echo $final; ?> €.</h1>
                    <br><br>
                    <input type="button" value="Cierra Esta Ventana" onclick="window.close()">
				</div>
            </div>
        <div class="col-md-1"></div>
    </div>
</section>
<?php
include "inc/footer.html";
?>