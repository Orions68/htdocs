<?php
include "includes/conn.php";
if (isset($_POST["hand"]))
{
    $material = "";
    $price = "";
    $job = $_POST["job"];
    for ($i = 0; $i < (count($_POST) - 5) / 2; $i++)
    {
        $material .= $_POST["material" . $i] . ", ";
        $price .= $_POST["price" . $i] . ",";
    }
    $price_array = explode(",", $price);
    $hand = $_POST["hand"];
    $total = 0;
    $date = $_POST["date"];
    $time = $_POST["time"];
    $date = $date;
    $time = $time;
    for ($i = 0; $i < count($price_array) - 1; $i++)
    {
        $total += $price_array[$i];
    }
    $igic = 1.05;
    $total += $hand;
    $totaligic = $total * $igic;
    $sql = "INSERT INTO invoice VALUES(:id, :job, :material, :price, :hand, :total, :igic, :totaligic, :date, :time)";
    $stmt = $conn->prepare($sql);
    $stmt->execute(array(':id' => null, ':job' => $job, ':material' => $material, ':price' => $price, ':hand' => $hand, ':total' => $total, ':igic' => "5%", ':totaligic' => $totaligic, ':date' => $date, ':time' => $time));
    echo "<script>if (!alert('Factura de Monto " . $totaligic . " Agregada a la Base de Datos.')) window.open('index.php', '_self');</script>";
}
?>