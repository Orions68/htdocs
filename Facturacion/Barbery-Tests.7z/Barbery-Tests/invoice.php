<?php
session_start();
setlocale(LC_TIME, 'es_ES.UTF-8');
// date_default_timezone_set("Europe/London");
date_default_timezone_set("America/Argentina/Buenos_Aires");
$invoice = $_POST['invoice'];
$name = $_POST["username"];
$date = date("Y-m-d");
$time = date("H:i:s");
$total = 0;
$iva = 0;
$title = "Facturación de La Peluquería de Javier Borneo";
include "includes/header.php";
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.2/js/bootstrap.min.js" integrity="sha512-5BqtYqlWfJemW5+v+TZUs22uigI8tXeVah5S/1Z6qBLVO7gakAOtkOzUtgq6dsIo5c0NJdmGPs0H9I+2OHUHVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/script.js"></script>
<script src="js/functions.js"></script>
<img alt="logo" src="img/logo.jpg" height="300" width="100%"/>
<br>
<section class="container-fluid pt-3">
    <div class="row">
        <div class="col-md-1" style="width: 2%;"></div>
            <div class="col-md-10">
                <div id="view1">
					<br><br>
					<?php
					echo '<div id="printable">';
					echo "<h3>La Peluquería de Javier Borneo</h3>";
					echo "<p>Factura a: " . $name . "</p>";
						echo '<div class="row">';
						echo '<div class="column left" style="background-color:#aaa;">';
						echo "Artículo";
						echo '</div>';
						echo '<div class="column middle" style="background-color:#bbb; text-align:right;">';
						echo "Precio";
						echo '</div>';
						echo '<div class="column right" style="background-color:#ccc; text-align:right;">';
						echo "Cantidad";
						echo '</div>';
						echo '<div class="column moreright" style="background-color:#c1c; text-align:right;">';
						echo "Parcial";
						echo '</div>';
						echo '<div class="column moreright" style="background-color:#c8c; text-align:right;">';
						echo "I.V.A.";
						echo '</div>';
						echo '<div class="column moreright" style="background-color:#cfc; text-align:right;">';
						echo "Total";
						echo '</div>';
						echo '</div>';

					$record = explode (",", $invoice);
					for ($i = 0; $i < count($record) - 3; $i+=4)
					{
						echo '<div class="row">';
						echo '<div class="column left" style="background-color:#aaa;">';
						echo $record[$i + 1];
						echo '</div>';
						echo '<div class="column middle" style="background-color:#bbb; text-align:right;">';
						echo $record[$i + 2] . "$";
						echo '</div>';
						echo '<div class="column right" style="background-color:#ccc; text-align:right;">';
						echo $record[$i + 3];
						echo '</div>';
						echo '<div class="column moreright" style="background-color:#c1c; text-align:right;">';
						$total += $record[$i + 3] * $record[$i + 2];
						echo number_format((float)$record[$i + 3] * $record[$i + 2], 2, '.', '') . "$";
						echo '</div>';
						echo '<div class="column moreright" style="background-color:#c8c; text-align:right;">';
						$iva += $record[$i + 3] * $record[$i + 2] * .21;
						echo number_format((float)$record[$i + 3] * $record[$i + 2] * .21, 2, '.', '') . "$";
						echo '</div>';
						echo '<div class="column moreright" style="background-color:#cfc; text-align:right;">';
						echo number_format((float)$record[$i + 3] * $record[$i + 2] + $record[$i + 3] * $record[$i + 2] * .21, 2, '.', '') . "$";
						echo '</div>';
						echo '</div>';
					}
					echo '<div class="column total" style="background-color:#000; text-align:right; color:white; margin-left:32%">Total I.V.A. Incluido: ' . number_format((float)$total + $iva, 2, '.', '') . '$</div>';
					echo '</div>';
					echo '<br>';
					echo '<br>';
					echo '<br>';
					echo '<br>';
					echo '<form action="addInvoice.php" method="post">';
					$j = 0;
					for ($i = 0; $i < count($record) - 3; $i+=4)
					{
						echo '<input type="hidden" name="id' . $j . '" value="' . $record[$i] . '">';
						echo '<input type="hidden" name="price' . $j . '" value="' . $record[$i + 2] . '">';
						echo '<input type="hidden" name="qtty' . $j . '" value="' . $record[$i + 3] . '">';
						$j++;
					}
					echo '<input type="hidden" name="username" value="' . $name . '">';
					echo '<input type="hidden" name="total" value="' . $total . '">';
					echo '<input type="hidden" name="iva" value="' . $iva . '">';
					echo '<input type="hidden" name="date" value="' . $date . '">';
					echo '<input type="hidden" name="time" value="' . $time . '">';
					echo '<input type="button" onclick="printIt(this.form)" value="Imprimir Ticket" style="width:160px; height:60px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
					echo '<input type="submit" value="Generar Ticket" style="width:160px; height:60px;">';
					echo '</form>';
					?>
				</div>
            </div>
        <div class="col-md-1" style="width: 2%;"></div>
    </div>
</section>
</body>

</html>