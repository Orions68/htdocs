<?php
include "includes/conn.php";
$title = "Guardando la Factura";
include "includes/header.php";
include "includes/modal-dismiss.html";
for ($i = 0; $i < (count($_POST) - 4) / 3; $i++)
{
    $id[$i] = $_POST["id" . $i];
    $qtty[$i] = $_POST["qtty" . $i];
    $iva[$i] = $_POST["iva". $i];
}
$name = $_POST['username'];
$total = $_POST["total"];
$date = $_POST['date'];
$time = $_POST['time'];
$iva1 = 0;
$service = "";
$qtty1 = "";
for ($i = 0; $i < count($id); $i++)
{
    $service .= $id[$i] . ",";
    $qtty1 .= $qtty[$i] . ",";
    $iva1 += $iva[$i];
}
$stmt = $conn->prepare('INSERT INTO invoice VALUES(:id, :client_id, :service_id, :qtty, :total, :iva, :date, :time)');
if (isset($_SESSION["client"]))
{
    $stmt->execute(array(':id' => null, ':client_id' => $_SESSION["client"], ':service_id' => $service, ':qtty' => $qtty1, ':total' => $total, ':iva' => $iva1, ':date' => $date, ':time' => $time));
}
else
{
    $stmt->execute(array(':id' => null, ':client_id' => null, ':service_id' => $service, ':qtty' => $qtty1, ':total' => $total, ':iva' => $iva1, ':date' => $date, ':time' => $time));
}
// session_destroy(); // Cierra la sesión de Cliente, para poder cerrar la sesión hay que abrirla previamente con session_start(), en este caso entá en el script conn.php incluido arriba.
echo "<script>toast('0', 'Factura de Monto: " . $total . "', 'Almacenada Correctamente en la base de datos.');</script>";
?>
</body>

</html>